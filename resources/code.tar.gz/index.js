// @ts-ignore FIX
export default function ({ res }) {
  return res.json({
    message: "Hello World",
  });
}
